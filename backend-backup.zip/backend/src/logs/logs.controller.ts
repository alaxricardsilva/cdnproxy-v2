import { Controller, Get, Req } from '@nestjs/common';
import { Request } from 'express';
import { LogsService } from './logs.service';

@Controller('api/logs')
export class LogsController {
  constructor(private readonly logsService: LogsService) {}

  @Get()
  getLogs(@Req() req: Request) {
    // Captura IP real do cliente, mesmo atrás de proxy/CDN
    let realIp = '';
    const forwarded = req.headers['x-forwarded-for'];
    if (typeof forwarded === 'string') {
      realIp = forwarded.split(',')[0].trim();
    } else if (Array.isArray(forwarded)) {
      realIp = forwarded[0];
    } else {
      realIp = req.socket.remoteAddress || req.ip || '';
    }
    // Passa IP real para o service
    return this.logsService.getLogs(realIp);
  }
}