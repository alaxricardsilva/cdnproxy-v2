import { Injectable } from '@nestjs/common';

@Injectable()
export class LogsService {
  constructor() {
    console.log('LogsService inicializado');
  }
  private logs: any[] = [];

  /**
   * Registra um novo log de acesso/analytics
   * @param logData Dados do acesso (device, IP, episódio, userAgent, etc)
   */
  registerAccessLog(logData: {
    ip: string;
    deviceInfo: any;
    episode?: string;
    userAgent?: string;
    timestamp?: number;
    [key: string]: any;
  }) {
    // Remover duplicidade de ip
    const { ip, ...rest } = logData;
    const log = {
      ip,
      ...rest,
      timestamp: Date.now(),
      device: logData.deviceInfo,
      episode: logData.episode || null,
      userAgent: logData.userAgent || null
    };
    this.logs.push(log);
    return log;
  }

  /**
   * Retorna todos os logs registrados
   */
  getLogs(ip?: string) {
    if (ip) {
      return this.logs.filter(log => log.ip === ip);
    }
    return this.logs;
  }
}