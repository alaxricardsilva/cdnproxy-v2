export class Payment {
  id!: number;
  user_id?: string;
  amount?: number;
  status?: string;
  created_at?: Date;
  updated_at?: Date;
}